# Luminous Rehab Mobile Design v2 final

This is a code bundle for Luminous Rehab Mobile Design v2 final. The original project is available at https://www.figma.com/design/SAhKq9ynisH0llytoDyKHH/Luminous-Rehab-Mobile-Design-v2-final.

## Running the code

Run `npm i` to install the dependencies.

Run `npm run dev` to start the development server.
