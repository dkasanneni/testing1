import { createPlaceholderScreen } from '../../utils/createPlaceholderScreen';
export default createPlaceholderScreen('User Details', '#10B981', '#059669');
