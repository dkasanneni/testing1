import { createPlaceholderScreen } from '../../utils/createPlaceholderScreen';
export default createPlaceholderScreen('Patient Details', '#10B981', '#059669');
